Coloca aquí los logos (SVG/PNG) que quieras mostrar en el onboarding.

- Ruta esperada: `public/logos/*.svg` (o `.png`).
- Se usan desde el código como `/logos/nombre.svg`.
- Este repositorio incluye `placeholder.svg` para que el build no falle aunque falten logos.

Sugerencia:
- Usa SVG optimizado (por ejemplo con SVGO).
- Mantén alturas similares para que el carrusel se vea uniforme.
